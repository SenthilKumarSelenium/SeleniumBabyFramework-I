package Property;

//http://selftechy.com/2011/06/20/creating-configuration-properties-for-selenium-test-suite//
public class Property2 {
     static String as="C:\\SeleniumDEMO\\GreensFrameWork\\src\\DataDrivenTxt\\TestData.txt";
     public void main(String as[])
     {
     }
     public String show() {
         return "C:\\SeleniumDEMO\\GreensFrameWork\\src\\DataDrivenTxt\\TestData.txt";
  }
}
