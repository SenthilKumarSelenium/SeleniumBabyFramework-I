package seleniumWebdriver;

import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.SeleneseTestCase;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverBackedSelenium;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.util.regex.Pattern;
import jxl.Sheet;
import jxl.Workbook;

public class ExcelDataDriven extends SeleneseTestCase {
	private String inputFile;

	public void setInputFile(String inputFile) {
		this.inputFile = inputFile;
	}
	@Before
	public void setUp() throws Exception {
		WebDriver driver = new FirefoxDriver();
		String baseUrl = "http://www.gmail.com/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
	}

	@Test
	public void testUntitled() throws Exception {
		
		setInputFile("C:/SeleniumDEMO/GreensFrameWork/src/DataDrivenExcel/TestData.xls");
		File inputWorkbook = new File(inputFile);
		Workbook w;
		w = Workbook.getWorkbook(inputWorkbook);
		// Get the first sheet
		Sheet sheet = w.getSheet(0);
		System.out.println("I got a label " + sheet.getCell(0,0).getContents());
			
		selenium.open("https://accounts.google.com/ServiceLogin?service=mail&passive=true&rm=false&continue=http://mail.google.com/mail/&scc=1&ltmpl=default&ltmplcache=2");
		assertEquals("Gmail: Email from Google", selenium.getTitle());
		Thread.sleep(2000);
		selenium.type("xpath=.//*[@id='Email']", sheet.getCell(0,0).getContents());
		selenium.type("id=Passwd", sheet.getCell(1,0).getContents());
	}

	@After
	public void tearDown() throws Exception {
		//selenium.stop();
	}
}

