package seleniumWebdriver;


import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.SeleneseTestCase;
import commonMethod.XMLMETHOD;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverBackedSelenium;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.regex.Pattern;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.io.File;
import java.util.regex.Pattern;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class XMLDataDriven extends SeleneseTestCase {
	@Before
	public void setUp() throws Exception {
		WebDriver driver = new FirefoxDriver();
		String baseUrl = "http://www.gmail.com/";
		selenium = new WebDriverBackedSelenium(driver, baseUrl);
	}
	@Test
	public void testUntitled() throws Exception {
		File xmlFile = new File("C:\\SeleniumDEMO\\GreensFrameWork\\src\\DataDrivenXML\\testdata.xml");
        DocumentBuilderFactory dbFactory =  DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(xmlFile);
        doc.getDocumentElement().normalize();
        NodeList nList = doc.getElementsByTagName("student");
        Node nNode = nList.item(1);
               if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                   Element eElement = (Element) nNode;
                   
        String user=new XMLMETHOD().getTagValue("username", eElement);
        String pass=new XMLMETHOD().getTagValue("password", eElement);
        
		selenium.open("https://accounts.google.com/ServiceLogin?service=mail&passive=true&rm=false&continue=http://mail.google.com/mail/&scc=1&ltmpl=default&ltmplcache=2");
		assertEquals("Gmail: Email from Google", selenium.getTitle());
		Thread.sleep(2000);
		selenium.type("xpath=.//*[@id='Email']", user);
		selenium.type("id=Passwd", pass);
     
       }
	}

	@After
	public void tearDown() throws Exception {
		//selenium.stop();
	}
}
